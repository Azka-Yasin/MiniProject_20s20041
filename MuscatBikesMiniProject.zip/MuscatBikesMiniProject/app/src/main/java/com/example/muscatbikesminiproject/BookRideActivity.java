package com.example.muscatbikesminiproject;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class BookRideActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    EditText edRentalName, edRentalNumb, edRentalDate, edRentalTime;
    Button clearbtn, calcbtn, bookbikebtn;
    Spinner hoursSpinner, bikeSpinner;
    TextView displaycost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_ride);
        getSupportActionBar().setTitle("Home Page");

        ActionBar bar= getSupportActionBar();
        ColorDrawable cd= new ColorDrawable(Color.parseColor("#fac457"));
        bar.setBackgroundDrawable(cd);

        hoursSpinner= (Spinner) findViewById(R.id.hourspinner);
        bikeSpinner= (Spinner) findViewById(R.id.bikespinner);
        clearbtn= (Button)findViewById(R.id.clearbtn1);
        calcbtn=(Button) findViewById(R.id.costbtn);
        bookbikebtn=(Button) findViewById(R.id.bookbtn1);
        edRentalName=(EditText) findViewById(R.id.edBookingName);
        edRentalNumb=(EditText) findViewById(R.id.edBookingPhone);
        edRentalDate=(EditText) findViewById(R.id.edBookingDate);
        edRentalTime=(EditText) findViewById(R.id.edBookingTime);
        displaycost=(TextView) findViewById(R.id.textView5);


//drop down lists
        String[] rentalhours= getResources().getStringArray(R.array.hours);
        ArrayAdapter adapter= new ArrayAdapter(this, android.R.layout.simple_spinner_item,rentalhours);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hoursSpinner.setAdapter(adapter);


        String[] biketype= getResources().getStringArray(R.array.bikes);
        ArrayAdapter adapter2= new ArrayAdapter(this, android.R.layout.simple_spinner_item,biketype);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        bikeSpinner.setAdapter(adapter2);

//buttons functions
        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edRentalName.getText().clear();
                edRentalNumb.getText().clear();
                edRentalDate.getText().clear();
                edRentalTime.getText().clear();
                displaycost.setText("0");
            }
        });

        calcbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hourlyrate= 5;
                int hoursneeded= hoursSpinner.
            }
        });

        bookbikebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //adding to database code
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if (adapterView.getId() ==R.id.hourspinner){
            String valueFromSpinner = adapterView.getItemAtPosition(i).toString();
            displaycost.setText();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}