package com.example.muscatbikesminiproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BookServiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_service);
    }
}